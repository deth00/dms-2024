<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Cookie;
use View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        View::composer('*', function($view)
        {
            $count_doc_type = Http::get('http://192.168.128.193:8080/api/doc-type');
            $data_doc_type = $count_doc_type['data'];
            $username = Cookie::get('user_name');
            $rolename = Cookie::get('role_id');
            View::share(['data_doc_type'=>$data_doc_type,'username'=>$username,'rolename'=>$rolename]);
        });
    }
}
