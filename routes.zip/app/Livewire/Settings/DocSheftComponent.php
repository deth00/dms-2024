<?php

namespace App\Livewire\Settings;

use Livewire\Component;

class DocSheftComponent extends Component
{
    public function render()
    {
        return view('livewire.settings.doc-sheft-component');
    }
}
