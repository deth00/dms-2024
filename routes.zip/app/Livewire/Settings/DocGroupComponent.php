<?php

namespace App\Livewire\Settings;

use Livewire\Component;

class DocGroupComponent extends Component
{
    public function render()
    {
        return view('livewire.settings.doc-group-component');
    }
}
