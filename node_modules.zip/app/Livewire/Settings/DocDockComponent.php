<?php

namespace App\Livewire\Settings;

use Livewire\Component;

class DocDockComponent extends Component
{
    public function render()
    {
        return view('livewire.settings.doc-dock-component');
    }
}
