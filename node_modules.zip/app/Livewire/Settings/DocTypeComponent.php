<?php

namespace App\Livewire\Settings;

use Livewire\Component;

class DocTypeComponent extends Component
{
    public function render()
    {
        return view('livewire.settings.doc-type-component');
    }
}
