<?php

namespace App\Livewire\Settings;

use Livewire\Component;

class DocDpartmentComponent extends Component
{
    public function render()
    {
        return view('livewire.settings.doc-dpartment-component');
    }
}
