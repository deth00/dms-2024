<?php

namespace App\Livewire\Settings;

use Livewire\Component;

class DocDpartComponent extends Component
{
    public function render()
    {
        return view('livewire.settings.doc-dpart-component');
    }
}
